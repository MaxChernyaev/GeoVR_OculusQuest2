using System;
using UnityEngine;

[Serializable]
public class JsonRadarogramReader : MonoBehaviour
{
    [Serializable]
    public class images
    {
        [SerializeField]
        public int[] jpg0/* = new int[2] {1504, 300}*/;
        [SerializeField]
        public int[] jpg1/* = new int[2] {1504, 300}*/;
        [SerializeField]
        public int[] jpg2/* = new int[2] {1504, 300}*/;
        [SerializeField]
        public int[] jpg3;
    }

    [Serializable]
    public class CommonData
    {
        [SerializeField]
        public images images;

        [SerializeField]
        public double time/* = 1623911573.2986324*/;

        [SerializeField]
        public string id;
    }

}
