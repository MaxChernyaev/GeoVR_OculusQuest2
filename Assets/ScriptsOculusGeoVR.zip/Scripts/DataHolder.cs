public static class DataHolder
{
    public static bool SplitCameraON;
    public static bool CheckBox = true; // перераспознавать QR-код

    public static string TextIP;
}